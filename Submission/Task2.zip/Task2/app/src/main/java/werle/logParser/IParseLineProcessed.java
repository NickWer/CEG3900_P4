package werle.logParser;

/**
 * Handles each line being processed
 * Created by nick on 3/13/17.
 */

public interface IParseLineProcessed {
    public void onLineProcessed(String line);
}
